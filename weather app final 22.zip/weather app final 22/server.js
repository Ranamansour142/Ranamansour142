// Setup empty JS object to act as endpoint for all routes
//it is demand projectData
projectData = {};


// Require Express to run server and routes
const express = require ("express")

//cors acheieve croos-origin so that can tell to the server
const cors = require ("cors")
//body-parser achieve jSON data
const bodyparser = require ("body-parser");

const {implementation} = require("express");
const {forward} = require("express/lib/response");

// Start up an instance of app
const app = express()

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Cors for cross origin allowance
app.use(cors())
// Initialize the main project folder
app.use(express.static('website'));


// Setup Server
const port=3000;
app.listen(port, () => {
    console.log (' server is running on port : ${port}')
}) 
app.get("/getweatherData" , (req, res) => {
    res.send( projectData)
})

app.post("/serverData" , (req, res) => {
    // projectData.heat = req.body.heat
    //projectData.specificDate = req.body.specificDate
    //projectData.sense = req.body.sense

    res.end()

})




